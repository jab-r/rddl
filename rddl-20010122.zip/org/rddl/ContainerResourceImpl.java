/**
 *	Resource Directory Description Language (RDDL) API
 *
 *	An XML-DEV project
 *	http://www.rddl.org/
 *
 *	This module, both source code and documentation, is in the Public Domain, 
 *	and comes with NO WARRANTY
 *
 *	@filename: resourceimpl.java
 *  @class: org.rddl.ResourceImpl
 *	@version: 0.1
 *  @date: 2001-01-06
 *	@author: Jonathan Borden <a href="mailto:jonathan@openhealth.org">jonathan@openhealth.org</a>
 */
package org.rddl;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URLConnection;
import java.net.URL;

import java.util.Iterator;
import java.util.SortedMap;
import java.util.TreeMap;
//
//
// ResourceImpl
//
//
public class ContainerResourceImpl implements Resource,Container
{
	public String getHref() 
	{
		return href;
	}
	public String getPurpose() 
	{
		return arcrole;
	}
	public String getNature() 
	{
		return role;
	}
	public String getTitle()
	{
		return title;
	}
	public String getId() 
	{
		return id;
	}
	public String getLang() 
	{
		return lang;
	}
	public String getBaseURI() {
		return baseURI;
	}

	public SortedMap getResourcesFromPurpose(String arcrole)
	{
		return arcroleMap.subMap(arcrole,arcrole+"\0");
	}
	public SortedMap getResourcesFromHref(String href)
	{
		return hrefMap.subMap(href,href+"\0");
	}
	public SortedMap getResourcesFromNature(String role)
	{
		return roleMap.subMap(role,role+"\0");
	}
	public SortedMap getResourcesFromTitle(String title)
	{
		return titleMap.subMap(title,title+"\0");
	}
	public SortedMap getResourcesFromLang(String lang)
	{
		return langMap.subMap(lang,lang+"\0");
	}
	public Resource getResourceFromId(String id)
	{
		return (Resource) idMap.get(id);
	}
	public SortedMap getResourcesFromIdRange(String id0,String id1)
	{
		return idMap.subMap(id0,id1);
	}
	public Iterator getResources()
	{
		return arcroleMap.values().iterator();
	}
	public String getURI() {
		return (baseURI==null) ? "#"+id : baseURI + "#" + id;
	}

	protected TreeMap arcroleMap = new TreeMap();
	protected TreeMap hrefMap = new TreeMap();
	protected TreeMap roleMap = new TreeMap();
	protected TreeMap titleMap = new TreeMap();
	protected TreeMap langMap = new TreeMap();
	protected TreeMap idMap = new TreeMap();

	protected ContainerResourceImpl(String id,String base,String ar,String r,String hr,String title,String lang)
	{
		baseURI = base;
		arcrole = ar;
		role = r;
		href = hr;
		this.id = id;
		this.lang = lang;
		this.title = title;
	};

	protected String href;
	protected String title;

	protected String role;
	protected String arcrole;
	protected String id;
	protected String lang;
	protected String baseURI;

}

