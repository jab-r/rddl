package org.rddl;

class AmbiguousMappingException extends Exception
{
}