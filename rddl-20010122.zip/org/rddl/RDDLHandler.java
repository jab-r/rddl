/**
 *	Resource Directory Description Language (RDDL) API
 *
 *	An XML-DEV project
 *	http://www.rddl.org/
 *
 *	This module, both source code and documentation, is in the Public Domain, 
 *	and comes with NO WARRANTY
 *
 *	@filename: rddlhandler.java
 *  @class: org.rddl.RDDLHandler
 *	@version: 0.1
 *  @date: 2001-01-06
 *	@author: Jonathan Borden <a href="mailto:jonathan@openhealth.org">jonathan@openhealth.org</a>
 */
package org.rddl;

import java.util.Stack;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import org.xml.sax.helpers.DefaultHandler;

//
//
// RDDLHandler
//
//
class RDDLHandler extends DefaultHandler
{
	protected NamespaceImpl parent;
	protected String rootNS = null;
	protected String rootLocalName = null;
	protected boolean bRoot = true;
	protected int resourceCount = 0;
	protected Stack stateStack = new Stack();
	// initial state
	protected boolean bStarted = false;
	protected int index = 0;
	protected String currentId = "";
	protected Resource currentResource = null;
    public void startElement (String namespaceURI, String localName,
			      String qName, Attributes atts)
				  throws SAXException {
		/*
			check what the namespace of the root element is
			if its XHTML then its RDDL (assuming rddl:resource elements are found)
			if not, then save the namespaceURI and punt ... the namespaceURI of the root
			element does tell us something about what we got back.
		*/
		if (bRoot) {
			rootNS = namespaceURI;
			rootLocalName = localName;
			if (!rootNS.equals(Mappings.XHTML_NS))
				throw new SAXException(namespaceURI);
			bRoot = false;
			bStarted = true;
		} else if (namespaceURI.equals(Mappings.RDDL_NS) &&
			localName.equals("resource")) {
			/*
				tag state includes:
					siblingCount -- bStarted resets count to 0
					bStarted -- set to true at end of startElement, false at end of endElement
					id
					resource
			*/
			resourceCount += 1;
				
			String arcrole = atts.getValue(Mappings.XLINK_NS,"arcrole");
			String href = atts.getValue(Mappings.XLINK_NS,"href");
			String role = atts.getValue(Mappings.XLINK_NS,"role");
			String title = atts.getValue(Mappings.XLINK_NS,"title");
			String lang = atts.getValue("xml:lang");
			String base = atts.getValue("xml:base");
			String id = atts.getValue("id");
			
			//String rootNS = Mappings.getRootNamespaceURIFromArcrole(arcrole);
			ResourceImpl res = new ResourceImpl(
										id,
										(base == null) ? parent.namespaceURI : base,
										arcrole,
										role,
										href,
										title,
										null,
										lang
										);
			if (role == null)
				role = Mappings.RDDL_NS + "#resource";

			parent.roleMap.put(role,(Resource)res);
			if (arcrole != null)
				parent.arcroleMap.put(arcrole,(Resource)res);
			if (lang != null)
				parent.langMap.put(lang,(Resource)res);
			if (title != null)
				parent.titleMap.put(title,(Resource)res);

			if (href != null)
				parent.hrefMap.put(href, (Resource) res);
			// save state of parent
			stateStack.push(new State(currentId,currentResource,index,bStarted));
			// set state of this element
			if (bStarted)
				index = 1;
			else
				index += 1;
			bStarted = true;
			if (id != null) {
				currentId = id;
			} else {
			/*
				currentId builds what ought to be a proper ChildSeq however
				not all XHTML elements are being tracked...
			*/
				currentId = currentId + "/" + (new Integer(index)).toString();
			};
			currentResource = res;
			parent.idMap.put(currentId, (Resource) res);
	
		} else if (namespaceURI.equals(Mappings.XHTML_NS) &&
					localName.equals("div")) {
			String id = atts.getValue("id");
			String lang = atts.getValue(Mappings.XML_NS,"lang");
			ContainerResourceImpl cont = null;
			String role = "http://www.rddl.org/natures#container";
			String arcrole = "http://www.rddl.org/natures#collection";
	
			if (id != null) {
				cont = new ContainerResourceImpl(
										id,
										null,
										arcrole,
										role,
										null,
										null,
										lang
										);
			};
			stateStack.push(new State(currentId,currentResource,index,bStarted));
			if (bStarted)
				index = 1;
			else
				index += 1;
			bStarted = true;

				currentId = id;					
				currentResource = (Resource) cont;
		};
	}
	public void endElement( String namespaceURI,
              String localName,
              String qName ) throws SAXException {
		if (namespaceURI.equals(Mappings.RDDL_NS) &&
					localName.equals("resource")) {
			State state = (State) stateStack.pop();
			currentId = state.id;
			currentResource = state.resource;
			index = state.siblingCount;
			bStarted = false;
		} else if (namespaceURI.equals(Mappings.XHTML_NS) &&
					localName.equals("div")) {
			State state = (State) stateStack.pop();
			if (state.id != null) {
				currentId = state.id;
				currentResource = state.resource;
			}
			index = state.siblingCount;
			bStarted = false;
		};
   }


	protected RDDLHandler(NamespaceImpl par) {
		resourceCount = 0;
		parent = par;
	};
}

