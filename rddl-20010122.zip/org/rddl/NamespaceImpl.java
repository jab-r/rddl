package org.rddl;

import java.util.SortedMap;
import java.util.Iterator;
import java.util.TreeMap;

public class NamespaceImpl implements Namespace {
	public SortedMap getResourcesFromNature(String role)
	{
		return roleMap.subMap(role,role+"\0");
	}
	public SortedMap getResourcesFromPurpose(String arcrole)
	{
		return arcroleMap.subMap(arcrole,arcrole+"\0");
	}
	public SortedMap getResourcesFromHref(String href)
	{
		return hrefMap.subMap(href,href+"\0");
	}

	public SortedMap getResourcesFromTitle(String title)
	{
		return titleMap.subMap(title,title+"\0");
	}
	public SortedMap getResourcesFromLang(String lang)
	{
		return langMap.subMap(lang,lang+"\0");
	}
	public SortedMap getResourcesFromIdRange(String id0,String id1)
	{
		if (id0 == null) {
			if (id1 == null)
				return idMap;
			else 
				return idMap.tailMap(id1);
		} else if (id1 == null) {
			return idMap.headMap(id0);
		} else
		return idMap.subMap(id0,id1);
	}

	public Resource getResourceFromId(String id)
	{
		return (Resource) idMap.get(id);
	}
	public Iterator getResources()
	{
		return roleMap.values().iterator();
	}
	public String getURI() {
		return namespaceURI;
	}
	protected NamespaceImpl(String URI) {
		namespaceURI = URI;
	}
	protected TreeMap arcroleMap = new TreeMap();
	protected TreeMap hrefMap = new TreeMap();
	protected TreeMap roleMap = new TreeMap();
	protected TreeMap titleMap = new TreeMap();
	protected TreeMap langMap = new TreeMap();
	protected TreeMap idMap = new TreeMap();
	protected String namespaceURI;
}
