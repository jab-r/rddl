package org.rddl;

import java.util.SortedMap;
import java.util.Iterator;

public interface Namespace extends Container {
 /* public abstract SortedMap getResourcesFromPurpose(String arcrole);
	public abstract SortedMap getResourcesFromHref(String href);
	public abstract SortedMap getResourcesFromNature(String href);
	public abstract SortedMap getResourcesFromTitle(String title);
	public abstract SortedMap getResourcesFromLang(String lang);
	public abstract Resource getResourceFromId(String id);
	public abstract Iterator getResources();
	public abstract String getURI();
 */
}
