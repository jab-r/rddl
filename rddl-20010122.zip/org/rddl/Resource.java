/**
 *	Resource Directory Description Language (RDDL) API
 *
 *	An XML-DEV project
 *	http://www.rddl.org/
 *
 *	This module, both source code and documentation, is in the Public Domain, 
 *	and comes with NO WARRANTY
 *
 *	@filename: resource.java
 *  @class: org.rddl.Resource
 *	@version: 0.1
 *  @date: 2001-01-06
 *	@author: Jonathan Borden <a href="mailto:jonathan@openhealth.org">jonathan@openhealth.org</a>
 */
package org.rddl;
import java.net.URLConnection;
import java.io.InputStream;
/**
 * Resource
 *
 * <blockquote>
 * <em>This module, both source code and documentation, is in the
 * Public Domain, and comes with <strong>NO WARRANTY</strong>.</em>
 * </blockquote>
 *
 *	@author Jonathan Borden <a href="mailto:jonathan@openhealth.org">jonathan@openhealth.org</a>
 */
public interface Resource {
    /**
     * Get the resource xlink:arcrole.
	 *
	 * <rddl:resource xlink;arcrole="..." />
     *
     * <p>This method gets the xlink:arcrole which corresponds to the type of the link.
	 . 
	 * The arcrole may be either an absolute or relative URI reference, though under most circumstances will be 
	 * an absolute URI. A fragment identifier should be present. The base URI is the URI of
	 * the RDDL document containing the resource. Arcroles for well known types are
	 * defined in <a href="http://www.rddl.org/arcrole.htm">this</a> RDDL document.</p>
     *
     */
 	public abstract String getPurpose();
 	public abstract String getNature();
	public abstract String getBaseURI();
    /**
     * Get the resource xlink:href.
	 *
	 * <rddl:resource xlink;href="..." />
     *
     * <p>This method gets the resource's URI which corresponds to the xlink:href. 
	 * The href may be either an absolute or relative URI. The base URI is the URI of
	 * the RDDL document containing the resource.</p>
     *
     */
 	public abstract String getHref();
	public abstract String getId();
	public abstract String getLang();
    /**
     * Get the resource xlink:role.
	 *
	 * <rddl:resource xlink;role="http://www.rddl.org/#resource" />
     *
     * <p>This method gets the xlink:role which corresponds to the type of the related resource. In RDDL 1.0
	 * the role must be <code>http://www.rddl.org/#resource</code>.
	 *
	 * The role may be either an absolute or relative URI reference, though under most circumstances will be 
	 * an absolute URI. A fragment identifier should be present. The base URI is the URI of
	 * the RDDL document containing the resource.</p>
     *
     */

 	public abstract String getTitle();
};