package org.rddl;

public class Mappings {

	static final String XLINK_NS = "http://www.w3.org/1999/xlink";
	static final String XHTML_NS = "http://www.w3.org/1999/xhtml";
	static final String RDDL_NS = "http://www.rddl.org/";
	static final String RDDL_resource = "http://www.rddl.org/#resource";
	static final String MIME_URI_prefix = "http://www.isi.edu/in-notes/iana/assignments/media-types/";
	static final String XML_NS = "http://www.w3.org/XML/1998/namespace";
	
	static final String URI_CSS = "http://www.rddl.org/arcrole.htm#CSS";

	static final String getContentTypeFromNature(String nature){
		if (nature.startsWith(MIME_URI_prefix))
			return nature.substring(MIME_URI_prefix.length());
		else
		return null;
		}
	static final String getNatureFromContentType(String ct) {
		return MIME_URI_prefix + ct;
	}
	static final String getRootNamespaceURIFromNature(String nature){
		return nature;
		}
}
