package org.rddl;

import java.util.SortedMap;
import java.util.Iterator;

public interface Container {
	public abstract SortedMap getResourcesFromNature(String href);
	public abstract SortedMap getResourcesFromPurpose(String arcrole);
	public abstract SortedMap getResourcesFromHref(String href);
	public abstract SortedMap getResourcesFromTitle(String title);
	public abstract SortedMap getResourcesFromLang(String lang);
	public abstract SortedMap getResourcesFromIdRange(String id0,String id1);
	public abstract Resource getResourceFromId(String id);
	public abstract Iterator getResources();
	public abstract String getURI();
}
