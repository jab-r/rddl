package org.rddl;

class State {
	protected int siblingCount;
	protected String id;
	protected Resource resource;
	protected boolean bStarted;
	protected State(String id, Resource res, int sibcount, boolean bstart) {
		this.id = id;
		this.resource = res;
		this.siblingCount = sibcount;
		this.bStarted = bstart;
		}
}
